

# screenshot_keyword.py
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:5000/log"
KEYWORD = "ERROR"
LINES_BELOW = 5   # 👈 关键字下面截多少行

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()

    page.goto(URL)
    page.wait_for_selector(".line")

    # 找到关键字所在行
    locator = page.locator(f".line:has-text('{KEYWORD}')").first

    if locator.count() == 0:
        print("❌ 没找到关键字")
        browser.close()
        exit()

    # 滚动到关键字
    locator.scroll_into_view_if_needed()

    # 获取所有行
    all_lines = page.locator(".line")
    total = all_lines.count()

    # 当前行 index
    index = locator.evaluate("el => parseInt(el.getAttribute('data-index'))")

    # 计算结束行
    end_index = min(index + LINES_BELOW, total - 1)

    # 起始元素 & 结束元素
    start_el = all_lines.nth(index)
    end_el = all_lines.nth(end_index)

    start_box = start_el.bounding_box()
    end_box = end_el.bounding_box()

    # 计算截图区域
    clip = {
        "x": start_box["x"],
        "y": start_box["y"],
        "width": start_box["width"],
        "height": (end_box["y"] + end_box["height"]) - start_box["y"]
    }

    # 截图
    page.screenshot(path="keyword.png", clip=clip)

    print("✅ 已生成 keyword.png")

    browser.close()