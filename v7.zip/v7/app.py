

# app.py
from flask import Flask, Response
import html

app = Flask(__name__)

LOG_FILE = "test.log"

@app.route("/log")
def show_log():
    with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    # 每一行变成一个 div（关键点）
    html_lines = ""
    for i, line in enumerate(lines):
        safe_line = html.escape(line)
        html_lines += f'<div class="line" data-index="{i}">{safe_line}</div>'

    page = f"""
    <html>
    <body style="background:black;color:white;font-family:monospace;">
    {html_lines}
    </body>
    </html>
    """

    return Response(page, mimetype="text/html")


if __name__ == "__main__":
    # 必须 0.0.0.0 才能远程访问
    app.run(host="0.0.0.0", port=5000)