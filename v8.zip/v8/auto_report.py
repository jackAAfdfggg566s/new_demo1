

from flask import Flask, send_file, jsonify
import paramiko
import time
import os
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches

app = Flask(__name__)

# =========================
# 🔧 配置（按你环境改）
# =========================
HOST = "172.28.136.214"
USER = "feng"
PASSWORD = "root.123"

REMOTE_SCRIPT = "/tmp/run_test.sh"
REMOTE_LOG = "/tmp/test.log"

LOCAL_LOG = "test.log"
IMAGE_FILE = "error.png"
WORD_FILE = "report.docx"

KEYWORD = "ERROR"
LINES_BELOW = 6


# =========================
# 1️⃣ 执行远端脚本
# =========================
def run_remote():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, username=USER, password=PASSWORD)

    print("🚀 执行远端脚本...")
    ssh.exec_command(f"bash {REMOTE_SCRIPT}")

    ssh.close()


# =========================
# 2️⃣ 等待日志生成
# =========================
def wait_log_ready(timeout=30):
    print("⏳ 等待日志生成...")
    for _ in range(timeout):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(HOST, username=USER, password=PASSWORD)

        stdin, stdout, _ = ssh.exec_command(f"test -f {REMOTE_LOG} && echo ok")
        result = stdout.read().decode().strip()

        ssh.close()

        if result == "ok":
            print("✅ 日志已生成")
            return

        time.sleep(1)

    raise Exception("❌ 日志未生成")


# =========================
# 3️⃣ 拉取日志
# =========================
def fetch_log():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, username=USER, password=PASSWORD)

    sftp = ssh.open_sftp()
    sftp.get(REMOTE_LOG, LOCAL_LOG)

    sftp.close()
    ssh.close()

    print("📥 已拉取日志")


# =========================
# 4️⃣ 提取关键字区域（支持多个）
# =========================
def extract_sections():
    with open(LOCAL_LOG, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    sections = []
    for i, line in enumerate(lines):
        if KEYWORD in line:
            section = lines[i:i + LINES_BELOW]
            sections.append(section)

    if not sections:
        sections = [["No ERROR found\n"]]

    return sections


# =========================
# 5️⃣ 生成图片（多张）
# =========================
def generate_images(sections):
    image_files = []

    try:
        font = ImageFont.truetype("DejaVuSansMono.ttf", 18)
    except:
        font = ImageFont.load_default()

    for idx, section in enumerate(sections):
        width = 1200
        line_height = 24
        height = line_height * len(section) + 40

        img = Image.new("RGB", (width, height), "black")
        draw = ImageDraw.Draw(img)

        y = 20
        for line in section:
            color = "red" if KEYWORD in line else "white"
            draw.text((20, y), line.strip(), fill=color, font=font)
            y += line_height

        filename = f"error_{idx}.png"
        img.save(filename)
        image_files.append(filename)

    print("🖼 图片生成完成")
    return image_files


# =========================
# 6️⃣ 生成 Word（支持模板）
# =========================
def generate_word(images):
    # 如果你有模板，用这个：
    TEMPLATE = "template.docx"

    if os.path.exists(TEMPLATE):
        doc = Document(TEMPLATE)
    else:
        doc = Document()

    doc.add_heading("自动化测试报告", 0)

    for i, img in enumerate(images):
        doc.add_paragraph(f"错误 {i+1}")
        doc.add_picture(img, width=Inches(6))

    doc.save(WORD_FILE)

    print("📄 Word 生成完成")


# =========================
# 7️⃣ 主流程
# =========================
def run_all():
    run_remote()
    wait_log_ready()
    fetch_log()
    sections = extract_sections()
    images = generate_images(sections)
    generate_word(images)


# =========================
# API：一键执行
# =========================
@app.route("/run")
def run():
    try:
        run_all()
        return jsonify({
            "status": "success",
            "download": "/download"
        })
    except Exception as e:
        return jsonify({"error": str(e)})


# =========================
# API：下载 Word
# =========================
@app.route("/download")
def download():
    return send_file(WORD_FILE, as_attachment=True)
    
# =========================
# 启动
# =========================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)