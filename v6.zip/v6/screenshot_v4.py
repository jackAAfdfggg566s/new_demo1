import os
import time
import requests
from flask import Flask, request, jsonify
from PIL import Image, ImageDraw, ImageFont
import textwrap

# ====== 配置 ======

GITLAB_URL = "https://gitlab.com"
PROJECT_ID = 81014910
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"

SCREENSHOT_DIR = "screenshots"
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

app = Flask(__name__)

# =========================
# 1️⃣ 等待 pipeline 完成
# =========================
def wait_pipeline(project_id, pipeline_id, token, timeout=600):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}"
    headers = {"PRIVATE-TOKEN": token}

    start = time.time()

    while True:
        r = requests.get(url, headers=headers)
        data = r.json()
        status = data.get("status")

        print(f"[pipeline {pipeline_id}] status = {status}")

        if status in ["success", "failed", "canceled", "manual"]:
            return status

        if time.time() - start > timeout:
            return "timeout"

        time.sleep(5)


# =========================
# 2️⃣ 获取 jobs
# =========================
def get_jobs(project_id, pipeline_id, token):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}/jobs"
    headers = {"PRIVATE-TOKEN": token}

    r = requests.get(url, headers=headers)
    jobs = r.json()

    result = []
    for job in jobs:
        result.append({
            "id": job["id"],
            "name": job["name"]
        })

    return result


# =========================
# 3️⃣ 获取 job log
# =========================
def get_job_trace(project_id, job_id, token):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/jobs/{job_id}/trace"
    headers = {"PRIVATE-TOKEN": token}

    r = requests.get(url, headers=headers)

    if r.status_code != 200:
        return f"Failed to get log for job {job_id}"

    return r.text


# =========================
# 4️⃣ text → image
# =========================
def text_to_image(text, filename, width=1000, font_size=18):
    font = ImageFont.load_default()

    wrapper = textwrap.TextWrapper(width=100)

    lines = []
    for line in text.split("\n"):
        lines.extend(wrapper.wrap(line) or [""])

    line_height = font_size + 6
    height = max(200, line_height * (len(lines) + 2))

    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)

    y = 10
    for line in lines:
        draw.text((10, y), line, fill="black", font=font)
        y += line_height

    img.save(filename)


# =========================
# 5️⃣ 核心：生成截图（其实是 log → image）
# =========================
def capture_job_screenshots(jobs):
    for job in jobs:
        print(f"[job] processing: {job['name']}")

        # 获取 log
        log_text = get_job_trace(PROJECT_ID, job["id"], TOKEN)

        # 截短避免图片爆炸
        log_text = log_text[-8000:]

        # 文件名
        file_path = os.path.join(
            SCREENSHOT_DIR,
            f"{job['name'].replace('/', '_')}.png"
        )

        # 转图片
        text_to_image(log_text, file_path)

        print(f"[saved] {file_path}")


# =========================
# 6️⃣ Flask 接口
# =========================
@app.route("/capture")
def capture():
    pipeline_id = request.args.get("pipeline")

    if not pipeline_id:
        return jsonify({"error": "pipeline id required"}), 400

    # 1. 等 pipeline 完成
    status = wait_pipeline(PROJECT_ID, pipeline_id, TOKEN)

    if status not in ["success", "failed", "canceled", "manual"]:
        return jsonify({
            "error": "pipeline not ready",
            "status": status
        }), 400

    # 2. 获取 jobs
    jobs = get_jobs(PROJECT_ID, pipeline_id, TOKEN)

    if not jobs:
        return jsonify({"error": "no jobs found"}), 404

    # 3. 生成图片（同步执行）
    capture_job_screenshots(jobs)

    # 4. 返回结果
    return jsonify({
        "message": "done",
        "pipeline": pipeline_id,
        "jobs": len(jobs),
        "output_dir": SCREENSHOT_DIR
    })


# =========================
# 7️⃣ 启动
# =========================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)