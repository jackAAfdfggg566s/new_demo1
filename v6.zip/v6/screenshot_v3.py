import os
import time
import requests
import asyncio
from flask import Flask, request, jsonify
from playwright.async_api import async_playwright

# ====== 配置 ======


GITLAB_URL = "https://gitlab.com"
PROJECT_ID = 81014910
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"



SCREENSHOT_DIR = "screenshots"
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

app = Flask(__name__)

# ====== 等待 pipeline 完成 ======
def wait_pipeline(project_id, pipeline_id, token, timeout=600):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}"
    headers = {"PRIVATE-TOKEN": token}

    start = time.time()
    while True:
        r = requests.get(url, headers=headers)
        data = r.json()
        status = data.get("status")

        print(f"pipeline {pipeline_id} status: {status}")

        if status in ["success", "failed", "canceled", "manual"]:
            return status

        if time.time() - start > timeout:
            return "timeout"

        time.sleep(5)


# ====== 获取 jobs ======
def get_jobs(project_id, pipeline_id, token):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}/jobs"
    headers = {"PRIVATE-TOKEN": token}

    r = requests.get(url, headers=headers)
    jobs = r.json()

    result = []
    for job in jobs:
        result.append({
            "name": job["name"],
            "url": job["web_url"]
        })

    return result


# ====== Playwright 截图（async）======
async def capture_job_screenshots(jobs):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)

        for job in jobs:
            page = await browser.new_page()

            print(f"capturing: {job['name']}")

            try:
                await page.goto(job["url"], timeout=60000)
                await page.wait_for_timeout(3000)

                file_path = os.path.join(
                    SCREENSHOT_DIR,
                    f"{job['name'].replace('/', '_')}.png"
                )

                await page.screenshot(path=file_path, full_page=True)

            except Exception as e:
                print(f"error capturing {job['name']}: {e}")

            await page.close()

        await browser.close()


# ====== Flask 接口 ======
@app.route("/capture")
def capture():
    pipeline_id = request.args.get("pipeline")
    if not pipeline_id:
        return jsonify({"error": "pipeline id required"}), 400

    # 1️⃣ 等待 pipeline 完成
    status = wait_pipeline(PROJECT_ID, pipeline_id, TOKEN)
    if status not in ["success", "failed", "canceled", "manual"]:
        return jsonify({
            "error": f"pipeline {pipeline_id} not ready",
            "status": status
        }), 400

    # 2️⃣ 获取 jobs
    jobs = get_jobs(PROJECT_ID, pipeline_id, TOKEN)
    if not jobs:
        return jsonify({"error": "no jobs found"}), 404

    # 3️⃣ 调用 async 截图（关键）
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(capture_job_screenshots(jobs))

    return jsonify({
        "message": f"screenshots captured for pipeline {pipeline_id}",
        "jobs": len(jobs)
    })


# ====== 启动 ======
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)