import os
import time
import requests
from flask import Flask, request, jsonify
from playwright.sync_api import sync_playwright

# ======================
# 配置
# ======================

GITLAB_URL = "https://gitlab.com"
PROJECT_ID = 81014910
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"

SCREENSHOT_DIR = "screenshots"
LOGIN_STATE = "gitlab_state.json"

os.makedirs(SCREENSHOT_DIR, exist_ok=True)

app = Flask(__name__)


# ======================
# 1️⃣ 等待 pipeline 完成
# ======================
def wait_pipeline(project_id, pipeline_id, token, timeout=600):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}"
    headers = {"PRIVATE-TOKEN": token}

    start = time.time()

    while True:
        r = requests.get(url, headers=headers)
        status = r.json().get("status")

        print(f"[pipeline {pipeline_id}] status = {status}")

        if status in ["success", "failed", "canceled", "manual"]:
            return status

        if time.time() - start > timeout:
            return "timeout"

        time.sleep(5)


# ======================
# 2️⃣ 获取 jobs
# ======================
def get_jobs(project_id, pipeline_id, token):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}/jobs"
    headers = {"PRIVATE-TOKEN": token}

    r = requests.get(url, headers=headers)
    jobs = r.json()

    result = []
    for job in jobs:
        result.append({
            "id": job["id"],
            "name": job["name"],
            "web_url": job["web_url"]
        })

    return result


# ======================
# 3️⃣ Playwright 截图（关键）
# ======================
def capture_job_screenshots(jobs):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)

        # 🔥 使用登录态（重点）
        if os.path.exists(LOGIN_STATE):
            context = browser.new_context(storage_state=LOGIN_STATE)
        else:
            context = browser.new_context()

        for job in jobs:
            page = context.new_page()

            print(f"[capture] {job['name']}")

            try:
                page.goto(job["web_url"], timeout=60000)

                # 等待 log UI 加载
                page.wait_for_timeout(5000)

                # 如果没登录，会跳转 sign in
                if "sign_in" in page.url:
                    print("未登录，截图为登录页")
                
                file_path = os.path.join(
                    SCREENSHOT_DIR,
                    f"{job['name'].replace('/', '_')}.png"
                )

                page.screenshot(path=file_path, full_page=True)

            except Exception as e:
                print(f"error: {job['name']} -> {e}")

            page.close()

        browser.close()


# ======================
# 4️⃣ Flask API
# ======================
@app.route("/capture")
def capture():
    pipeline_id = request.args.get("pipeline")

    if not pipeline_id:
        return jsonify({"error": "pipeline id required"}), 400

    # 1. 等 pipeline
    status = wait_pipeline(PROJECT_ID, pipeline_id, TOKEN)

    if status not in ["success", "failed", "canceled", "manual"]:
        return jsonify({"error": "pipeline not ready", "status": status}), 400

    # 2. jobs
    jobs = get_jobs(PROJECT_ID, pipeline_id, TOKEN)

    if not jobs:
        return jsonify({"error": "no jobs found"}), 404

    # 3. 截图
    capture_job_screenshots(jobs)

    return jsonify({
        "message": "done",
        "pipeline": pipeline_id,
        "jobs": len(jobs),
        "output": SCREENSHOT_DIR
    })


# ======================
# 5️⃣ 启动
# ======================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)