import time
import requests
from playwright.sync_api import sync_playwright

# ============ 配置 =============
GITLAB_URL = "https://gitlab.com"
PROJECT_ID = 81014910         # 项目ID
PIPELINE_ID = 2436016722      # pipeline ID
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"  # Personal Access Token
SCREENSHOT_DIR = "./screenshots"  # 截图保存目录

# ============ 工具函数 ==========
def wait_pipeline(project_id, pipeline_id, token):
    """等待 pipeline 完成"""
    headers = {"PRIVATE-TOKEN": token}
    while True:
        r = requests.get(f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}", headers=headers)
        if r.status_code != 200:
            print("Error fetching pipeline:", r.status_code, r.text)
            return None
        status = r.json().get("status")
        print(f"Pipeline {pipeline_id} status:", status)
        if status in ["success", "failed", "canceled","manual"]:
            return status
        #elif status == "manual":
            #print("Pipeline is manual. Please trigger manually or use a trigger token.")
            #return "manual"
        time.sleep(5)  # 每5秒轮询一次

def get_jobs(project_id, pipeline_id, token):
    """获取 pipeline 下所有 jobs"""
    headers = {"PRIVATE-TOKEN": token}
    r = requests.get(f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}/jobs", headers=headers)
    if r.status_code != 200:
        print("Error fetching jobs:", r.status_code, r.text)
        return []
    return r.json()  # 返回 jobs 列表

def capture_job_screenshots(jobs):
    """对每个 job 页面截图"""
    import os
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        for job in jobs:
            job_name = job["name"].replace("/", "_")
            job_url = job["web_url"]
            print("Capturing:", job_name, job_url)
            page = browser.new_page()
            page.goto(job_url)
            # 等待页面渲染完成（可根据需要增加等待条件）
            page.wait_for_timeout(3000)  # 3秒
            page.screenshot(path=f"{SCREENSHOT_DIR}/{job_name}.png")
            page.close()
        browser.close()
    print("All screenshots saved to", SCREENSHOT_DIR)

# ============ 主流程 ==========
if __name__ == "__main__":
    status = wait_pipeline(PROJECT_ID, PIPELINE_ID, TOKEN)
    if status in ["success", "failed", "canceled","manual"]:
        jobs = get_jobs(PROJECT_ID, PIPELINE_ID, TOKEN)
        if jobs:
            capture_job_screenshots(jobs)
        else:
            print("No jobs found.")
    else:
        print("Pipeline is not running. Cannot capture jobs.")