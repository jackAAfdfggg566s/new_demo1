#http://127.0.0.1:5000/capture?pipeline=2436016722

import requests
import time
from flask import Flask, send_file, request
from PIL import Image, ImageDraw, ImageFont

GITLAB_URL = "https://gitlab.com"
PROJECT_ID = "81014910"
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"


app = Flask(__name__)


# -------------------------
# 等待 pipeline 完成
# -------------------------
def wait_pipeline(pipeline_id):
    pipeline_id="2436016722"
    #url="https://gitlab.com/a4155949/abc/-/jobs/13821038854"
    #url = f"{GITLAB_URL}/a4155949/abc/-/jobs/{pipeline_id}"
    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/pipelines/{pipeline_id}"
    print("url!!:", url)
    headers = {"PRIVATE-TOKEN": TOKEN}
    
       # headers = {"PRIVATE-TOKEN": TOKEN}

   # r = requests.get(url, headers=headers)

    while True:

        r = requests.get(url, headers=headers)
        data = r.json()
        print("FULL JSON:", data) 
        status = data.get("status")

        print("pipeline status:", status)

        if status in ["success", "failed", "canceled"]:
            return status

        time.sleep(5)


# -------------------------
# 获取 job 列表
# -------------------------
def get_jobs(pipeline_id):
    pipeline_id="2436016722"
    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/pipelines/{pipeline_id}/jobs"
    #url = f"{GITLAB_URL}/a4155949/abc/-/jobs/{pipeline_id}"
    headers = {"PRIVATE-TOKEN": TOKEN}

    r = requests.get(url, headers=headers)

    return r.json()


# -------------------------
# 获取 job 日志
# -------------------------
def get_job_log(job_id):

    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/jobs/{job_id}/trace"
    headers = {"PRIVATE-TOKEN": TOKEN}

    r = requests.get(url, headers=headers)

    return r.text


# -------------------------
# 生成截图
# -------------------------
def text_to_image(text, output="pipeline.png"):

    lines = text.split("\n")

    width = 1200
    line_height = 20

    height = max(800, len(lines) * line_height + 50)

    img = Image.new("RGB", (width, height), "white")

    draw = ImageDraw.Draw(img)

    try:
        font = ImageFont.truetype("DejaVuSansMono.ttf", 16)
    except:
        font = ImageFont.load_default()

    y = 10

    for line in lines[:200]:   # 防止日志过长
        draw.text((10, y), line, fill="black", font=font)
        y += line_height

    img.save(output)

    return output


# -------------------------
# Flask API
# -------------------------
@app.route("/capture")
def capture():

    pipeline_id = request.args.get("pipeline")

    if not pipeline_id:
        return "pipeline id required"

    wait_pipeline(pipeline_id)

    jobs = get_jobs(pipeline_id)

    output_text = ""

    for job in jobs:

        name = job["name"]
        status = job["status"]
        job_id = job["id"]

        output_text += f"\n===== {name} ({status}) =====\n"

        log = get_job_log(job_id)

        output_text += log[:3000]   # 防止太长

    image_file = text_to_image(output_text)

    return send_file(image_file, mimetype="image/png")


if __name__ == "__main__":

    app.run(host="0.0.0.0", port=5000)