

from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    context = browser.new_context()

    page = context.new_page()
    page.goto("https://gitlab.com/users/sign_in")

    print("👉 请手动登录 GitLab（1分钟）")
    page.wait_for_timeout(60000)

    context.storage_state(path="gitlab_state.json")

    browser.close()