# #run fixgw asx nft02
#run remote

from flask import Flask, render_template, request, jsonify ,send_file
import configparser
import requests
import subprocess
import time
from screenshot import capture

GITLAB_URL = "https://gitlab.com"
PROJECT_ID = "81014910"
TRIGGER_TOKEN = "glptt-tAiaqExetbngV5A6W6j3"
REF = "main"


app = Flask(__name__)
CONFIG_FILE = "/mnt/d/vm/v5/config.cfg"

# ---------- 配置管理 ----------
def read_cfg():
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)
    data = {s: dict(config.items(s)) for s in config.sections()}
    return data

def write_cfg(data):
    config = configparser.ConfigParser()
    for section, values in data.items():
        config[section] = values
    with open(CONFIG_FILE, "w") as f:
        config.write(f)

@app.route("/")
def index():
    cfg = read_cfg()
    return render_template("index.html", config=cfg)

@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify(read_cfg())

@app.route("/api/config/update", methods=["POST"])
def update_config():
    req = request.json
    section = req.get("section")
    key = req.get("key")
    value = req.get("value")
    cfg = read_cfg()
    if section not in cfg:
        cfg[section] = {}
    cfg[section][key] = str(value)
    write_cfg(cfg)
    return jsonify({"status": "updated"})

# ---------- chatbot ----------
@app.route("/api/chat", methods=["POST"])
def chat():
    prompt = request.json.get("prompt", "").lower()

  
    if "fixgw" in prompt:
       
        #gitlab_url = "https://gitlab.com/your_project/api/v4/projects/PROJECT_ID/trigger/pipeline"
        #token = "YOUR_TRIGGER_TOKEN"
        gitlab_url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/trigger/pipeline"
        data = {"token": TRIGGER_TOKEN, "ref": REF, "variables[JOB_NAME]": "test_fix_gw_pod_failover"}
        r = requests.post(gitlab_url, data=data)
        return jsonify({"action": "gitlab_pipeline", "response": r.json()})

    elif "remote" in prompt:
      
        remote_host = "feng@172.28.136.214"
        script_path = "/mnt/d/vm/v5/test_script.sh"
        try:
            result = subprocess.run(
                ["ssh", remote_host, script_path],
                capture_output=True,
                text=True,
                timeout=60
            )
            return jsonify({"action": "remote_script", "stdout": result.stdout, "stderr": result.stderr})
        except Exception as e:
            return jsonify({"action": "remote_script", "error": str(e)})

    else:
        return jsonify({"action": "none", "message": "No action matched"})


@app.route("/screenshot")
def screenshot_page():
    return render_template("screenshot.html")



@app.route("/capture",methods=["POST"])
def capture_api():

    url=request.form["url"]
    #url="https://gitlab.com/a4155949/abc/-/jobs/13804904222"

    print("url:",url)

    
    
    filename=f"screenshot_{int(time.time())}.png"

    capture(url,filename)

    return send_file(filename,mimetype="image/png")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)