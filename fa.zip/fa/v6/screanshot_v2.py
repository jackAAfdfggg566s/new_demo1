import os
import time
import requests
from flask import Flask, request, jsonify
from playwright.sync_api import sync_playwright

# ============ 配置 ==========
GITLAB_URL = "https://gitlab.com"
PROJECT_ID = 81014910
TOKEN = "glpat-N08YdAquR_YjyXqJR0aLfWM6MQpvOjEKdTpldHludA8.01.171le36hv"
SCREENSHOT_DIR = "./screenshots"

# ============ Flask ==========
app = Flask(__name__)

# ============ 工具函数 ==========
def wait_pipeline(project_id, pipeline_id, token):
    """等待 pipeline 完成"""
    headers = {"PRIVATE-TOKEN": token}
    while True:
        r = requests.get(f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}", headers=headers)
        if r.status_code != 200:
            print("Error fetching pipeline:", r.status_code, r.text)
            return None
        status = r.json().get("status")
        print(f"Pipeline {pipeline_id} status:", status)
        if status in ["success", "failed", "canceled","manual"]:
            return status
        elif status == "manual":
            print("Pipeline is manual. Please trigger manually or use a trigger token.")
            return "manual"
        time.sleep(5)

def get_jobs(project_id, pipeline_id, token):
    """获取 pipeline 下所有 jobs"""
    headers = {"PRIVATE-TOKEN": token}
    r = requests.get(f"{GITLAB_URL}/api/v4/projects/{project_id}/pipelines/{pipeline_id}/jobs", headers=headers)
    if r.status_code != 200:
        print("Error fetching jobs:", r.status_code, r.text)
        return []
    return r.json()
    
def text_to_image(text, filename, width=800, font_size=20):
    """把文本生成图片"""
    lines = text.splitlines()
    font = ImageFont.load_default()  # 可换成 ttf
    # 估算高度
    height = len(lines) * (font_size + 4) + 20
    img = Image.new("RGB", (width, height), color=(255,255,255))
    draw = ImageDraw.Draw(img)
    y = 10
    for line in lines:
        draw.text((10, y), line, font=font, fill=(0,0,0))
        y += font_size + 4
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    img.save(filename)
    print("Saved text image:", filename)
    
def capture_job_screenshots(jobs):
    """循环截图 job 页面 + text_to_image"""
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        for job in jobs:
            job_name = job["name"].replace("/", "_")
            job_url = job["web_url"]
            print("Capturing webpage:", job_name, job_url)

            # ==== 网页截图 ====
            page = browser.new_page()
            page.goto(job_url)
            page.wait_for_timeout(5000)  # 等待页面渲染
            screenshot_path = os.path.join(SCREENSHOT_DIR, f"{job_name}.png")
            page.screenshot(path=screenshot_path)
            page.close()
            print("Saved screenshot:", screenshot_path)

            # ==== 文本转图片 ====
            # 可以使用 job summary / status / stage 等生成文本
            text_content = f"Job: {job['name']}\nStage: {job['stage']}\nStatus: {job['status']}\nPipeline ID: {job['pipeline']['id']}"
            text_image_path = os.path.join(SCREENSHOT_DIR, f"{job_name}_text.png")
            text_to_image(text_content, text_image_path)

#def capture_job_screenshots(jobs):
    ##"""循环截图 job 页面（沿用之前逻辑）"""
   # os.makedirs(SCREENSHOT_DIR, exist_ok=True)
   # with sync_playwright() as p:
      #  browser = p.chromium.launch(headless=True)
        #for job in jobs:
        #    job_name = job["name"].replace("/", "_")
        #    job_url = job["web_url"]
          #  print("Capturing:", job_name, job_url)
          #  page = browser.new_page()
            # 用你之前网页的方式访问 job 页面，等待渲染完成
            page.goto(job_url)
            # 等待页面渲染或日志加载完成，可以调大 timeout
          #  page.wait_for_timeout(5000)  # 5秒等待
           # screenshot_path = os.path.join(SCREENSHOT_DIR, f"{job_name}.png")
           # page.screenshot(path=screenshot_path)
           # page.close()
          #  print("Saved screenshot:", screenshot_path)
     #   browser.close()
   # print("All job screenshots saved to", SCREENSHOT_DIR)

# ============ Flask 路由 ==========
@app.route("/capture", methods=["GET"])
def capture():
    pipeline_id = request.args.get("pipeline")
    if not pipeline_id:
        return jsonify({"error": "pipeline id required"}), 400

    # 等待 pipeline 完成
    status = wait_pipeline(PROJECT_ID, pipeline_id, TOKEN)
    if status not in ["success", "failed", "canceled","manual"]:
        return jsonify({"error": f"pipeline {pipeline_id} not ready, status={status}"}), 400

    # 获取 jobs
    jobs = get_jobs(PROJECT_ID, pipeline_id, TOKEN)
    if not jobs:
        return jsonify({"error": "no jobs found"}), 404

    # 截图
    capture_job_screenshots(jobs)
    return jsonify({"message": f"screenshots captured for pipeline {pipeline_id}", "jobs": len(jobs)})

# ============ 启动 Flask ==========
if __name__ == "__main__":
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    app.run(host="0.0.0.0", port=5000)