
from flask import  request
import requests
from playwright.sync_api import sync_playwright
import time

def capture(url, filename):
    GITLAB_URL = "https://gitlab.com"
    PROJECT_ID = "81014910"
    PIPELINE_ID = "13821038854"
    TOKEN = "glptt-tAiaqExetbngV5A6W6j3"
    url="https://gitlab.com/a4155949/abc/-/jobs/13821038854"
    #url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/pipelines/{PIPELINE_ID}/jobs"
    headers = {"PRIVATE-TOKEN": TOKEN}

    r = requests.get(url, headers=headers)
    #jobs = r.json()

    #for job in jobs:
       # print(job["name"], job["status"], job.get("web_url"))
   
    try:
        jobs = r.json()
    except Exception as e:
        print("Failed to parse JSON:", e)
        print(r.text)
        jobs = []

    if isinstance(jobs, list):
        for job in jobs:
            print(job.get("name"), job.get("status"), job.get("web_url"))
    else:
        print("API did not return a list of jobs")

    with sync_playwright() as p:

        browser = p.chromium.launch(headless=True)
        #browser = p.chromium.launch(headless=False)
        context = browser.new_context()

        page = context.new_page()
        #page = browser.new_page()
        
        page.goto(url)
        page.wait_for_selector("div#pipeline-output", timeout=60000) 
        context.storage_state(path="storage.json")######
        time.sleep(5)

        page.screenshot(path=filename, full_page=True)

        browser.close()

    return filename
    
    

