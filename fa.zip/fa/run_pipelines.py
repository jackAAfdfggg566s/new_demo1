

import requests
import time

# ---------------------------
# GitLab configuration
# ---------------------------

GITLAB_URL="https://gitlab.com/"
PROJECT_ID = "81014910"
TRIGGER_TOKEN="glptt-tAiaqExetbngV5A6W6j3"
REF = "main"

# ---------------------------
# trigger pipeline
# ---------------------------

def run_pipeline(pipeline_type):

    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/trigger/pipeline"

    data = {
        "token": TRIGGER_TOKEN,
        "ref": REF,
        "variables[PIPELINE_TYPE]": pipeline_type
    }

    r = requests.post(url, data=data)

    if r.status_code != 201:
        print("Failed to trigger pipeline")
        print(r.text)
        exit(1)

    result = r.json()

    pipeline_id = result["id"]
    pipeline_url = result["web_url"]

    print(f"Pipeline started: {pipeline_type}")
    print(f"Pipeline URL: {pipeline_url}")

    return pipeline_id


# ---------------------------
# wait pipeline finish
# ---------------------------

def wait_pipeline(pipeline_id):

    print("Waiting pipeline finish...")

    while True:

        url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/pipelines/{pipeline_id}"

        headers = {
            "PRIVATE-TOKEN": TRIGGER_TOKEN
        }

        r = requests.get(url, headers=headers)

        status = r.json()["status"]

        print("status:", status)

        if status in ["success", "failed", "canceled"]:
            return status

        time.sleep(15)


# ---------------------------
# main workflow
# ---------------------------

def main():

    print("Run pipeline1")

    p1 = run_pipeline("test")

    wait_pipeline(p1)

    #print("Wait 2 minutes")

    #time.sleep(120)

    #print("Run pipeline2")

    #p2 = run_pipeline("pipeline2")

    #wait_pipeline(p2)

    #print("Run db query pipeline")

    #p3 = run_pipeline("db_query")

    #wait_pipeline(p3)

    #print("All pipelines finished")


if __name__ == "__main__":
    main()