from transformers import pipeline
import json
import requests

# ===== GitLab config =====
GITLAB_URL = "https://gitlab.com"
PROJECT_ID = "81014910"
TRIGGER_TOKEN = "glptt-tAiaqExetbngV5A6W6j3"
REF = "main"

# ===== AI model =====
generator = pipeline(
    "text2text-generation",
    model="google/flan-t5-base"
)

# ===== prompt template =====
def build_prompt(user_input):

    prompt = f"""
Convert the user request into JSON.

Definitions:
AMP_TYPE:
1=CBOE
2=NSX
3=ASX
4=SSX

NFT_TYPE:
1=nft01
2=nft02

JOB:
fix gw pod failover -> test_fix_gw_pod_failover
hptm pod failover -> test_hptm_pod_failover

Return JSON only.

Example:

Input:
run fix gw pod failover ASX nft02

Output:
{{"JOB_NAME":"test_fix_gw_pod_failover","AMP_TYPE":3,"NFT_TYPE":2}}

Input:
{user_input}

Output:
"""

    return prompt


# ===== parse prompt with LLM =====
def parse_prompt(user_input):

    prompt = build_prompt(user_input)

    result = generator(
        prompt,
        max_length=128
    )[0]["generated_text"]

    print("LLM raw output:", result)

    try:
        data = json.loads(result)
    except:
        raise Exception("LLM output not valid JSON")

    return data


# ===== trigger GitLab pipeline =====
def run_pipeline(params):

    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/trigger/pipeline"

    data = {
        "token": TRIGGER_TOKEN,
        "ref": REF
    }

    for k,v in params.items():
        data[f"variables[{k}]"] = v

    r = requests.post(url, data=data)

    print("Pipeline response:", r.json())


# ===== main =====
if __name__ == "__main__":

    user_input = input("Enter command: ")

    params = parse_prompt(user_input)

    print("Parsed:", params)

    run_pipeline(params)