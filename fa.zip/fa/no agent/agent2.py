

import re
import requests


GITLAB_URL = "https://gitlab.com"
PROJECT_ID = "81014910"
TRIGGER_TOKEN = "glptt-tAiaqExetbngV5A6W6j3"
REF = "main"

AMP_MAP = {
    "CBOE": 1,
    "NSX": 2,
    "ASX": 3,
    "SSX": 4
}

NFT_MAP = {
    "NFT01": 1,
    "NFT02": 2
}

def parse_prompt(prompt):

    #prompt = prompt.upper()
    prompt = str(prompt).strip().upper()

    job = None
   ## prompt = prompt.strip().lower()

    if "FIXGW" in prompt:
        print ("111111111")
        job = "test_fix_gw_pod_failover"

    amp_type = None
    nft_type = None

    for k,v in AMP_MAP.items():
        if k in prompt:
            amp_type = v

    for k,v in NFT_MAP.items():
        if k in prompt:
            nft_type = v

    return {
        "JOB_NAME": job,
        "AMP_TYPE": amp_type,
        "NFT_TYPE": nft_type
    }



def run_pipeline(params):

    
    url = f"{GITLAB_URL}/api/v4/projects/{PROJECT_ID}/trigger/pipeline"
    data = {
        "token": TRIGGER_TOKEN,
        "ref": REF
    }

    for k,v in params.items():
        if v:
            data[f"variables[{k}]"] = v

    r = requests.post(url,data=data)

    print(r.json())
    
    print("status:", r.status_code)
    print("response:", r.text)

# ===== main =====
if __name__ == "__main__":

    user_input = input("Enter command: ")

    params = parse_prompt(user_input)

    print("Parsed:", params)

    run_pipeline(params)
    
    
 #run fixgw asx nft02